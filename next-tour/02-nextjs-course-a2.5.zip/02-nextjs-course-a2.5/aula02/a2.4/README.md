
## Sobre tempo de build no Nextjs

```md
- SSG (next export) [4 posts]: 7.89s.
- SSG (next export) [1000 posts]: 27.23s.
- ISG (next build) [1000 posts]: 3.10s.
```
