function SobrePage() {
  return (
    <div>
      Você está na página sobre

      <ul>
        <li>
          <a href="/">Ir para a Home</a>
        </li>
      </ul>
    </div>
  )
}

export default SobrePage;
